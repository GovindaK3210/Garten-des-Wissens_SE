from django.apps import AppConfig


class GdwPostConfig(AppConfig):
    name = 'gdw_post'
