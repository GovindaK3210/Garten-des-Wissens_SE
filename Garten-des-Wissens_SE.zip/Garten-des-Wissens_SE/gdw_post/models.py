from django.db import models
from gdw_profile.models import Profile, Course
from django.urls import reverse

# Create your models here.
class Post (models.Model):
    user_profile = models.ForeignKey(Profile,on_delete=models.PROTECT)
    
    course_tags = models.ManyToManyField(Course, blank=True)

    description = models.TextField()
    title = models.CharField(max_length=300)
    picture = models.ImageField(blank=True)

    views = models.IntegerField(null=True)
    time = models.DateTimeField()
    votes = models.IntegerField(null=True)




    hasVoted = models.ManyToManyField(Profile, blank=True,related_name="hasVoted")
    # Comments 
    # Answers

    #course = models.ForeignKey(Course,null=True , on_delete=models.DO_NOTHING)
    #comments = models.ManyToManyField(Comment,null= True ,blank= True)
    #response = models.IntegerField(null=True)
    
    def get_absolute_url(self):
        return reverse('gdw_profile:post_detail',kwargs={'pk':self.pk})

    def __str__(self):
        return self.title

class Answer(models.Model):
    description = models.TextField()
    user_profile = models.ForeignKey(Profile,on_delete=models.DO_NOTHING)
    time = models.DateTimeField()
    post = models.ForeignKey(Post,on_delete=models.DO_NOTHING)
    votes = models.IntegerField()
    picture = models.ImageField(blank=True)

class Comment(models.Model):
    description = models.TextField()
    user_profile = models.ForeignKey(Profile,on_delete=models.DO_NOTHING)
    time = models.DateTimeField()
    post = models.ForeignKey(Post,on_delete=models.DO_NOTHING, blank=True)
    # answer = models.ForeignKey(Answer,on_delete=models.DO_NOTHING,blank=True)

