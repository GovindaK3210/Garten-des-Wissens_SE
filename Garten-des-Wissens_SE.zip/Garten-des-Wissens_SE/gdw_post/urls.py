from django.urls import path
from . import views

app_name = 'gdw_post'

urlpatterns = [

    path('search/',views.search, name='search'),

    path('search/(?P<string>[\w\-]+)/', views.query , name='query'),

    path('userProfile/post/create', views.PostCreate.as_view(), name='create_post'),
    path('search/delete_post/',views.delPost, name='delPost'),
    path('posts/<int:post_id>/add_comment/',views.AddComment, name='addComment'),
    

    path('posts/',views.posts, name='posts'),
    path('upVoted/(?P<post_id>[0-9]+)/', views.upVote, name='up_vote'),
    path('downVoted/(?P<post_id>[0-9]+)/', views.downVote, name='down_vote'),
    # /Music/album/2/delete

    path('userProfile/(?P<pk>[0-9]+)/delete', views.PostDelete.as_view(), name='post_delete'),
    path('posts/<int:post_id>/',views.post_view, name='post_view'),
]