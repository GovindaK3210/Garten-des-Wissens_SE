from .models import Post
from django import  forms

class PostForm(forms.ModelForm):
    class Meta:
        #in same table as in admin
        model = Post
        widgets = {
            'categories': forms.MultipleChoiceField,
        }
        fields = ['title', 'description','course_tags','picture']
    
    #def __init__(self, *args, **kwargs):
    #    super(PostForm, self).__init__(*args, **kwargs)
    #    self.fields['course_tags'].queryset = self.instance.course_tags.all()
