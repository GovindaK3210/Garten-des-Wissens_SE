from django.shortcuts import render, get_object_or_404
from django.views.generic.edit import CreateView,DeleteView
from .forms import PostForm
from .models import Post,Profile,Comment,Answer
from django.contrib.auth.models import User
import datetime

from django.urls import reverse_lazy
from django.http import JsonResponse
from django.core import serializers


# Create your views here.
def search(request):
    if request.method == 'GET':
        data = request.GET.copy()
        query = data.get('query')
        choice = data.get('choices-single-defaul')

        if query==None:
            return render(request,'search.html', {})
        
        if choice == 'Course':
            results = Post.objects.filter(course_tags__title__contains = query)
        elif choice == 'User':
            results = Post.objects.filter(user_profile__user__username__contains=query) 
        else:
            results = Post.objects.filter(title__contains=query)    
        # Search query
        #results = Post.objects.filter(title__contains=query)
        #print(query)
        #print("Reached!!!")
        return render(request,'results.html', {'results': results })

# Delete a post
def delPost(request):
    data = {'foo':'fail'}
    if (request.method == 'GET'):
        #get post_key and delete it
        #also delete all comments and anwsers on that post
        
        print("-----DeletingPost-----")
        data = {'foo':'success'}

    return JsonResponse({'rd' : data})


def query(request):
    if request.method == 'GET':
        data = request.POST.copy()
        query = data.get('query')
        print(query)
        print("Reached!!!")
    
    return render(request,"<h1>Reached</h1>", {})

def posts(request):
    results = Post.objects.all()
    
    return  render(request,'posts.html',  {'results': results })

def post_view(request,post_id):
    postobj = get_object_or_404(Post,pk=post_id) 
    comments = Comment.objects.filter(post=postobj)
    return render(request,'post_view.html', {'post': postobj, 'comments': comments})


class PostCreate (CreateView):
    model = Post
    template_name = 'gdw_profile/post_form.html'
    form_class = PostForm
    def post(self, request):
        form = self.form_class(request.POST, request.FILES)
        if form.is_valid():
            # we need to do futher validation
            post = form.save(commit=False)
            form.instance.user_profile = self.request.user.profile
            
            post.views = 0
            post.time = datetime.datetime.now()
            post.votes = 0

            post.save()

            # returns User objects if credentials are correct
            # Authentication
            return render(request, 'profile.html', {"user_model":self.request.user })

        return render(request, self.template_name, {'form': form})
                    # request.user.username
    def form_valid(self, form):
        form.instance.user = self.request.user
        # article.save()  # This is redundant, see comments.
        return super(PostCreate, self).form_valid(form)



class PostDelete(DeleteView):
        model = Post
        success_url = reverse_lazy('gdw:index')


def upVote(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    print(post.votes)
    post.votes = post.votes + 1
    print(post.votes)
    post.hasVoted.add(Profile.objects.get(id=request.user.profile.pk))
    for u in post.hasVoted.all() :
        print (u)
    post.save()

    user = User.objects.get(username=post.user_profile.user.username)
    followers = User.objects.filter(profile__followedUsers__user__username = user.username)
    return render(request, 'profile.html', {"user_model":post.user_profile.user , "no_of_followers":followers.count() })



def downVote(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    post.votes = post.votes - 1

    post.hasVoted.add(Profile.objects.get(id=request.user.profile.pk))
    for u in post.hasVoted.all() :
        print (u)
    post.save()
    user = User.objects.get(username=post.user_profile.user.username)
    followers = User.objects.filter(profile__followedUsers__user__username = user.username)
    return render(request, 'profile.html', {"user_model":post.user_profile.user , "no_of_followers":followers.count() })



def AddComment(request,post_id):
    dataC = {'foo':'asdfgh'}
    print("working")
    if (request.method == 'GET'):
        post_key = request.GET.get('post_key')
        comment_desc = request.GET.get('comment')
        temptime = datetime.datetime.now()
        comment = Comment(description=comment_desc,user_profile=request.user.profile,time=temptime,post=Post.objects.get(pk=post_id))
        #comment.description = comment_desc
        #comment.user_profile = request.user.profile
        #comment.time = datetime.datetime.now()
        #comment.post = Post.objects.get(pk=post_key)
        #Comment.objects.add(comment)
        comment.save()
        # course_id = request.GET['course_key']
        # course = get_object_or_404(Course,pk=course_id) 
        # request.user.profile.courses.add(course)
       
        dataC = {
                    'foo': comment_desc,
                    'bar': temptime,
                    }
        # a = serializers.serialize('json', dataC)

    return JsonResponse({'rd':dataC})