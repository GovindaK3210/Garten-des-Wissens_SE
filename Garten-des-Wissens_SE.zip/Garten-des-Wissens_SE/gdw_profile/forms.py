from .models import Profile,Course,College
from django import  forms

from datetime import datetime, timedelta
class ProfileForm(forms.ModelForm):
 #   courses = forms.ModelMultipleChoiceField(queryset=Course.objects.all())
#    colleges = forms.ModelMultipleChoiceField(queryset=College.objects.all())
    class Meta:
        #in same table as in admin
        model = Profile
        widgets = {
            'categories': forms.CheckboxSelectMultiple,
        }
        fields = ['FirstName', 'LastName', 'description', 'age', 'degree', 'city', 'country','picture' ,'courses','colleges']
