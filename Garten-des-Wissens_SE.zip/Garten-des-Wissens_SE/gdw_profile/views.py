from builtins import object

from django.shortcuts import render , get_object_or_404
from datetime import datetime, timedelta
from django.contrib.auth.models import User

# Create your views here.
from django.views.generic.edit import CreateView,UpdateView,DeleteView,model_forms
from .models import *
from django.urls import  reverse_lazy
from django.shortcuts import  redirect
from .forms import ProfileForm 
from  django.views import  generic
from django.http import JsonResponse


class ProfileCreate (CreateView):
    model = Profile
    template_name = 'gdw_profile/profile_form.html'
    form_class = ProfileForm
    def post(self, request):
        form = self.form_class(request.POST, request.FILES)
        if form.is_valid():
            # we need to do futher validation
            profile = form.save(commit=False)
            #FirstName = form.cleaned_data['FirstName']
            #LastName = form.cleaned_data['LastName']
            #description = form.cleaned_data['description']
            #age = form.cleaned_data['age']
            #degree = form.cleaned_data['degree']
            #city = form.cleaned_data['city']
            #country = form.cleaned_data['country']

            # cleamed (normalize) data
            #last_login= datetime.now()

            form.instance.user = self.request.user
            form.instance.register_date=datetime.today()
            form.instance.profile_views=0
            form.instance.last_login=datetime.now()
            profile.save()

            # returns User objects if credentials are correct
            # Authentication
            return redirect('gdw:index')

        return render(request, self.template_name, {'form': form})
                    # request.user.username
    def form_valid(self, form):
        form.instance.user = self.request.user
        # article.save()  # This is redundant, see comments.
        return super(ProfileCreate, self).form_valid(form)

    #def get(self,request):
    #    form = self.form_class(None)
    
   #     if request.user.is_authenticated:
    #        profile = Profile.objects.get(user=request.user)
     #       if profile != None:
      #          return redirect('gdw:profile', {'profile': profile})
            

       # return render(request,self.template_name, {'form': form})



class ProfileUpdate (UpdateView):
    model = Profile
    form_class = ProfileForm
    template_name = 'gdw_profile/profile_update.html'

    def post(self, request):
        try:
            profile = request.user.profile
        except Profile.DoesNotExist:
            profile = Profile(user=request.user)

        if request.method == 'POST':
            form = ProfileForm(request.POST, request.FILES, instance=profile)
            if form.is_valid():
                # Create, but don't save the new author instance.
                prof = form.save(commit=False)
                request.user.profile.colleges.clear()

                for college in form.cleaned_data['colleges'] :

                    obj = User_College(request.user.profile, college,datetime.now())
                    print (obj.college.name)
                    obj.save()
                #prof.colleges=form.colleges
                prof.courses.set(form.cleaned_data['courses'])
                #prof.courses=form.courses
                # Save the new instance.
                prof.save()
                # Now, save the many-to-many data for the form.
                #form.save_m2m()
                
                
                return redirect('gdw_profile:profile_view',username=request.user.username)

        else:
            form = ProfileForm(instance=profile)
            return render(request,'users/profile.html', {'form': form})
    def get_object(self):

        return get_object_or_404(Profile, pk=self.request.user.profile.pk)
class ProfileDelete (DeleteView):
    model = Profile
    success_url = reverse_lazy('gdw:index')
class DetailViews(generic.DetailView):
    model = Profile
    template_name = 'gdw_profile/profile_details.html'



def Profile_View(request,username):

    user = User.objects.get(username=username)
    followers = User.objects.filter(profile__followedUsers__user__username = username)
    # notifi = Notification.ob
    #colleges = user.profile.colleges.objects.get()
    #colleges = User_College.objects.get(user_profile=user.profile)
    

    return render(request, 'profile.html', {"user_model":user , "no_of_followers":followers.count() })
    

def followUser(request):
    data = {'foo':'fail'}
    if (request.method == 'GET'):

        usertofollow_id = request.GET.get('tofollow_key')
        usertofollow = get_object_or_404(User,pk=usertofollow_id) 
        follower_id = request.GET.get('fromfollow_key')
        follower = get_object_or_404(User,pk=follower_id) 

        follower.profile.followedUsers.add(usertofollow.profile)
        #get post_key and delete it
        #also delete all comments and anwsers on that post
    
        print("-----FollowingUser-----")
        data = {'foo':'success'}

    return JsonResponse({'rd' : data})