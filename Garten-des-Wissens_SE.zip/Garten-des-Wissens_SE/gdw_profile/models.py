from django.db import models
from django.contrib.auth.models import User

from gdw.models import *
from django.urls import reverse
# Create your models here.
class Profile(models.Model):

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    
    FirstName = models.CharField(max_length=150)
    LastName = models.CharField(max_length=150)
    

    description = models.TextField()
    age = models.IntegerField()
    degree = models.CharField(max_length=1000)
    city = models.CharField(max_length=500)
    country = models.CharField(max_length=500)
   
    picture=models.ImageField(blank=True)

    register_date = models.DateField(null=True)         # Remove
    profile_views = models.IntegerField(null=True)      # Implement
    last_login = models.DateTimeField(null=True)        # Remove

    # foreign keys
    colleges = models.ManyToManyField(College,through='User_College', blank=True)
    courses = models.ManyToManyField(Course, blank=True)
    followedUsers = models.ManyToManyField('self', blank=True, symmetrical=False)
    def get_absolute_url(self):
        return reverse('gdw_profile:profile_detail',kwargs={'pk':self.pk})

    def __str__(self):
        return self.user.username
    

class Notification(models.Model):
    user_profile = models.ForeignKey(User,on_delete=models.PROTECT)
    description = models.TextField()

    # post id link

    # profile id link
    #followed_by = User

    # 0 posts
    # 1 following
    notification_type = models.BooleanField()

    timestamp = models.DateTimeField()


class User_College(models.Model):
    user_profile = models.ForeignKey(Profile,on_delete=models.DO_NOTHING,  null=True)
    college = models.ForeignKey(College,on_delete=models.DO_NOTHING ,null=True)
    admission_date = models.DateField()

    def __init__(self, user_profile, college, admission_date, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.user_profile = user_profile
        self.college = college
        self.admission_date = admission_date