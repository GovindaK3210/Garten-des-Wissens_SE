from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.conf.urls import url
app_name = 'gdw_profile'

urlpatterns = [

    #path('profile/',views.Profile_View, name='profile_view'),
    url(r'profile/(?P<username>[a-zA-Z0-9]+)$', views.Profile_View,  name='profile_view'),
    #url(r'profile/update/$',views.ProfileUpdate,name='update_profile'),
    
    # /gdw_profile/
    path('userProfile/add',views.ProfileCreate.as_view(),name='create_profile'),
    
    url(r'^(?P<pk>[0-9]+)/$', views.DetailViews.as_view(), name='profile_details'),
    # /Music/album/2/
    path('userProfile/$', views.ProfileUpdate.as_view(), name='update_profile'),
    path('profile/follow_user/',views.followUser, name='followUser'),
    

] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)