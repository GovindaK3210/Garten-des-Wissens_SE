from django.apps import AppConfig


class GdwProfileConfig(AppConfig):
    name = 'gdw_profile'
