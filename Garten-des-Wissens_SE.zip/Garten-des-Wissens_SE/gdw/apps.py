from django.apps import AppConfig


class GdwConfig(AppConfig):
    name = 'gdw'
