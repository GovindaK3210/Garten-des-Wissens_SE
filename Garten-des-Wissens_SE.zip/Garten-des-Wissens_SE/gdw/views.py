from django.views import generic
from django.shortcuts import render, redirect , get_object_or_404, reverse
from django.contrib.auth import authenticate, login

from django.views.generic import View, RedirectView
from django.contrib.auth.models import User
from .forms import UserForm
from .models import College , Course
from django.http import JsonResponse

from gdw_post.models import Post, Comment
import datetime
# Create your views here.

def index(request):
    return render(request,"search.html")
    #template_name = 'base.html'
    #context_object_name = 'obj' # any name

    #def get_queryset(self):
    #    pass
        #return <>.objects.all()
    



def register(request):
    return render(request,"registration_form.html")

def navbar(request):
    return render(request,"navbar.html")

# List all courses page
def listCourses(request):

    all_courses =  Course.objects.all()
    context = {
        "Courses": all_courses,
    }
    return render(request,'listCourses.html',context)

# Subscibe to a course
def subsCourse(request):
    data = {'foo':'asdfgh'}
    if (request.method == 'GET'):
        course_id = request.GET['course_key']
        course = get_object_or_404(Course,pk=course_id) 
        request.user.profile.courses.add(course)
        data = {'foo':'success'}

    return JsonResponse({'rd' : data})

def listUsers(request):
    all_users = User.objects.all()
    
    return  render(request,'listUsers.html',{'Users':all_users})

def listColleges(request):
    all_colleges = College.objects.all()
    context = {
        "Colleges":all_colleges,
    }
    return  render(request,'listColleges.html',context)

def college_view(request,college_id):
    college = get_object_or_404(College,pk=college_id)  
    return render(request,'college_view.html', {'college': college})
class CollegeDetailRedirect(RedirectView):

    def get_redirect_url(self, college_id):
        college = get_object_or_404(College,pk=college_id)  
        return reverse('gdw:college_routine', args=(college_id))
        
def listCollegesRoutine(request,college_id):
    college = get_object_or_404(College,pk=college_id)
    return render(request,'college_routine.html', {'college': college})



    
def profile(request):
    return  render(request,'profile.html')

def awein(request):
    return  render(request,'awein.html',{ 'post' : Post.objects.get(pk=1)})


class UserFormView(View):
    form_class = UserForm
    template_name = "register.html" # Html File Name
    

    def get(self, request):
        form = self.form_class(None)
        return render(request,self.template_name, {'form': form})


    def post(self,request):
        form = self.form_class(request.POST)

        if form.is_valid():

            user = form.save(commit=False)
            #cleaned data
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user.set_password(password)
            user.save()

            # returns User objects if credentials are correct 
            user = authenticate(username= username,password=password)
            if user is not None:

                if user.is_active:
                    login(request,user)
                    return redirect('gdw_profile:create_profile')

            
        return render(request,self.template_name, {'form': form})

# def addComment(request):
#     dataC = {'foo':'asdfgh'}
#     if (request.method == 'GET'):
#         post_key = request.GET.get('post_key')
#         comment_desc = request.GET.get('comment')
        
#         comment = Comment(description=comment_desc,user_profile=request.user.profile,time=datetime.datetime.now(),post=Post.objects.get(pk=post_key))
#         #comment.description = comment_desc
#         #comment.user_profile = request.user.profile
#         #comment.time = datetime.datetime.now()
#         #comment.post = Post.objects.get(pk=post_key)
#         #Comment.objects.add(comment)
#         # comment.save()
#         # course_id = request.GET['course_key']
#         # course = get_object_or_404(Course,pk=course_id) 
#         # request.user.profile.courses.add(course)
#         dataC = {'foo': comment}

#     return JsonResponse({'rd' : dataC})