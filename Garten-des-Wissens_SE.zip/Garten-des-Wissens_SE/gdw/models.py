from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class Program(models.Model):
    title = models.CharField(max_length=500)

    def __str__(self):
        return self.title 

class Course(models.Model):
    code = models.CharField(max_length=10)
    title = models.CharField(max_length=500)
    credit_hr = models.IntegerField()

    def __str__(self):
        return  self.title





PROVINCE_CHOICES = (
    ('Khyber Pakhtunkhwa', 'Khyber Pakhtunkhwa'),
    ('Sindh', 'Sindh'),
    ('Islamabad Capital Territory', 'Islamabad Capital Territory'),
    ('Balochistan', 'Balochistan'),
    ('Azad Jammu & Kashmir', 'Azad Jammu & Kashmir'),
    ('Punjab', 'Punjab'),
    ('Gilgit Baltistan', 'Gilgit Baltistan'),
)

CHARTED_BY_CHOICES = (
    ('Government of Pakistan','Government of Pakistan'),
    ('Government of AJK','Government of AJK'),
    ('Government of Balochistan','Government of Balochistan'),
    ('Government of Khyber Pakhtunkhwa','Government of Khyber Pakhtunkhwa'),
    ('Government of Punjab','Government of Punjab'),
    ('Government of Sindh','Government of Sindh')
)
SECTOR_CHOICES = (
    ('Public', 'Public'),
    ('Private','Private'),
)

DISCIPLINE_CHOICES = (
    ('General','General'),
    ('Engineering & Technology','Engineering & Technology'),
    ('Art and Design','Art and Design'),
    ('Business Education','Business Education'),
    ('Medical','Medical'),
    ('Medicine and Healthcare','Medicine and Healthcare'),
    ('Science & Technology','Science & Technology')
)
class College(models.Model):
    name = models.CharField(max_length=500)
    sector = models.CharField(max_length=500,choices=SECTOR_CHOICES ,default='')
    chartered_By = models.CharField(max_length=500,choices=CHARTED_BY_CHOICES ,default='')
    discipline = models.CharField(max_length=500,choices=DISCIPLINE_CHOICES,default='')
    province = models.CharField(max_length=100,choices=PROVINCE_CHOICES,default='')
    city = models.CharField(max_length=500,default='')

    courses = models.ManyToManyField(Course)

    def __str__(self):
        return self.name + " --- " + self.city
