from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django import forms


class UserForm(UserCreationForm):
    
    email = forms.EmailField(max_length=254, help_text='Please provide a valid email address.')

    def __init__(self, *args, **kwargs):
        super(UserForm, self).__init__(*args, **kwargs)
        

        for fieldname in ['username', 'email', 'password1' , 'password2']:
            self.fields[fieldname].help_text = None
            
            #self.fields[fieldname].label = ''

    class Meta:
        model = User
        fields = ['username', 'email', 'password1' , 'password2']