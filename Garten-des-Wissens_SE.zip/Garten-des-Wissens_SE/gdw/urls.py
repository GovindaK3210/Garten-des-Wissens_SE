from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
from django.conf import settings
from django.conf.urls.static import static
app_name = 'gdw'

urlpatterns = [

    # /gdw/
    path('', views.index, name='index'),

    path('register/',views.UserFormView.as_view(), name='register'),
    path('register/login', auth_views.LoginView.as_view(template_name='userLogin.html'), name='login'),
    path('register/logout', auth_views.LogoutView.as_view(template_name='logout.html'), name='logout'),

    path('navbar/',views.navbar, name='navbar'),
    
    path('courses/',views.listCourses, name='courses'),
    path('courses/subscribe_course/',views.subsCourse, name='subsCourse'),
    # path('awein/add_comment/',views.addComment, name='addComment'),
    
    path('users/',views.listUsers, name='all_users'),

    path('colleges/',views.listColleges, name='colleges'),
    path('colleges/<int:college_id>/',views.college_view, name='college_view'),
    path('colleges/<int:college_id>/routine/',views.listCollegesRoutine, name='college_routine'),

    

    #path('register', views.register, name='register'),
    #path('login', views.login, name='login'),
    #path('register/logout', auth_views.LogoutView.as_view(template_name='logout.html'), name='logout'),

    path('profile/',views.profile, name='profile'),
    #path('profile/<int:profile_id>/',views.profile, name='profile'),
    path('awein/',views.awein, name='awein'),
    

] 