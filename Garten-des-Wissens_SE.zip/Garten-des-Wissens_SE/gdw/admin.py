from django.contrib import admin

from .models import *

# Register your models here.

admin.site.register(Program)
admin.site.register(Course)
admin.site.register(College)


# Register your models here.
admin.site.site_header = "Garten des Wissens Administration"
admin.site.site_title = "Admin - Garten des Wissens"